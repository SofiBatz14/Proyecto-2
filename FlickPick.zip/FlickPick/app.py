from flask import Flask, render_template, request, redirect, url_for, session
from neo4j import GraphDatabase

app = Flask(__name__)
app.secret_key = 'clave_secreta_para_sesiones'

# Usuario de prueba
usuario_prueba = {
    "usuario": "admin",
    "contraseña": "1234"
}

# Conexión a Neo4j
URI = "neo4j+s://de712a40.databases.neo4j.io"
AUTH = ("neo4j", "p-EI5G9cb-oLYFDLvPOwGx_KlAhbaJPEzHBc8lz2iT4")
driver = GraphDatabase.driver(URI, auth=AUTH)

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        usuario = request.form["usuario"]
        contraseña = request.form["contraseña"]
        if usuario == usuario_prueba["usuario"] and contraseña == usuario_prueba["contraseña"]:
            session["usuario"] = usuario
            return redirect(url_for("emociones"))
        else:
            return render_template("login.html", error="Credenciales incorrectas")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/emociones", methods=["GET", "POST"])
def emociones():
    if "usuario" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        emocion = request.form["emocion"]
        session["emocion"] = emocion
        return redirect(url_for("plataformas"))

    return render_template("emociones.html")

@app.route("/plataformas", methods=["GET", "POST"])
def plataformas():
    if "usuario" not in session or "emocion" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        plataforma = request.form["plataforma"]
        session["plataforma"] = plataforma
        return redirect(url_for("recomendaciones"))

    return render_template("plataformas.html")

@app.route("/recomendaciones")
def recomendaciones():
    if "usuario" not in session or "emocion" not in session or "plataforma" not in session:
        return redirect(url_for("login"))

    emocion = session["emocion"]
    plataforma = session["plataforma"]

    query = """
    MATCH (p:Pelicula)-[:PERTENECE_A]->(g:Genero),
          (p)-[:RELEVANTE_PARA]->(e:Emocion),
          (p)-[:DISPONIBLE_EN]->(pl:Plataforma)
    WHERE e.nombre = $emocion AND pl.nombre = $plataforma
    RETURN p.titulo AS titulo, p.sinopsis AS sinopsis, g.nombre AS genero, pl.nombre AS plataforma, p.poster_url AS imagen
    LIMIT 5
    """

    peliculas = []
    with driver.session() as session_db:
        resultados = session_db.run(query, emocion=emocion, plataforma=plataforma)
        peliculas = [r.data() for r in resultados]

    # Película extra de otra plataforma
    query_extra = """
    MATCH (p:Pelicula)-[:PERTENECE_A]->(g:Genero),
          (p)-[:RELEVANTE_PARA]->(e:Emocion),
          (p)-[:DISPONIBLE_EN]->(pl:Plataforma)
    WHERE e.nombre = $emocion AND pl.nombre <> $plataforma
    RETURN p.titulo AS titulo, p.sinopsis AS sinopsis, g.nombre AS genero, pl.nombre AS plataforma, p.poster_url AS imagen
    LIMIT 1
    """

    with driver.session() as session_db:
        extra_resultado = session_db.run(query_extra, emocion=emocion, plataforma=plataforma)
        peliculas += [r.data() for r in extra_resultado]

    plataforma_logo = {
        "Netflix": "netflix.png",
        "Prime Video": "prime_video.png",
        "MAX": "max.png"
    }.get(plataforma, "default_logo.png")

    return render_template("recomendaciones.html", peliculas=peliculas, plataforma=plataforma, plataforma_logo=plataforma_logo)

if __name__ == '__main__':
    app.run(debug=True, port=5000)